/* =============================================================
   ncs-menu / app.js
   Functionally equivalent to jav_menu — independent implementation
   ============================================================= */

'use strict';

/* ---- Helpers ---- */

function postNui(endpoint, data) {
    return fetch(`https://${GetParentResourceName()}/${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify(data ?? {})
    }).catch(() => {});
}

/* ---- Vue App ---- */

const app = new Vue({
    el: '#app',
    data() {
        return {
            menu: {
                open: false,
                dialog: {
                    open:  false,
                    title: '',
                    type:  null,
                    value: ''
                },
                title: '',
                index: 0,
                items: []
            },
            _scrollLock: false
        };
    },

    methods: {

        /* ---- Scroll ---- */

        scrollMenu(deltaY) {
            if (this.menu.items.length === 0) return;
            if (this._scrollLock) return;

            this._scrollLock = true;
            setTimeout(() => { this._scrollLock = false; }, 60);

            const scrollAudio = new Audio('./assets/sounds/scroll.mp3');
            scrollAudio.volume = 0.25;

            if (deltaY > 0) {
                const next = this.menu.index + 1;
                this.menu.index = next >= this.menu.items.length ? this.menu.items.length - 1 : next;
                scrollAudio.play().catch(() => {});
            } else if (deltaY < 0) {
                const next = this.menu.index - 1;
                this.menu.index = next < 0 ? 0 : next;
                scrollAudio.play().catch(() => {});
            }

            this.$nextTick(() => {
                const container = document.querySelector('.menu-items');
                const target = container?.querySelector(`.item:nth-child(${this.menu.index + 1})`);
                target?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            });
        },

        /* ---- Item selection ---- */

        selectCurrentItem() {
            const item = this.menu.items[this.menu.index];
            if (!item || !item.value) return;

            // Visual feedback on icon
            const selectIcon = document.querySelector('.item-option i.fa-computer-mouse');
            if (selectIcon) {
                selectIcon.classList.add('click');
                setTimeout(() => selectIcon.classList.remove('click'), 250);
            }

            const selectAudio = new Audio('./assets/sounds/select.wav');
            selectAudio.volume = 0.5;
            selectAudio.play().catch(() => {});

            postNui('menuItemSelected', { item });
        },

        handleItemClick(item) {
            if (this.menu.dialog.open) return;
            if (!item || !item.value) return;

            const selectAudio = new Audio('./assets/sounds/select.wav');
            selectAudio.volume = 0.5;
            selectAudio.play().catch(() => {});

            postNui('menuItemSelected', { item });
        },

        /* ---- Dialog ---- */

        submitDialog() {
            postNui('dialogValueSelected', {
                value: this.menu.dialog.value,
                type:  this.menu.dialog.type
            });
        },

        focusDialogInput() {
            this.$nextTick(() => {
                const input = this.$refs.dialogInput;
                if (input) input.focus();
            });
        },

        /* ---- NUI Message handler ---- */

        handleMessage(event) {
            const { type, data } = event.data ?? {};

            switch (type) {
                case 'menu:show':
                    this.menu.index = 0;
                    this.menu.title = data.title ?? '';
                    this.menu.items = Array.isArray(data.items) ? data.items : [];
                    this.menu.open  = true;
                    break;

                case 'menu:hide':
                    this.menu.open        = false;
                    this.menu.dialog.open = false;
                    this.menu.dialog.value = '';
                    break;

                case 'dialog:show':
                    if (this.menu.open) {
                        this.menu.dialog.type  = data.type  ?? 'text';
                        this.menu.dialog.title = data.title ?? '';
                        this.menu.dialog.value = '';
                        this.menu.dialog.open  = true;
                        this.focusDialogInput();
                    }
                    break;

                case 'dialog:hide':
                    this.menu.dialog.open  = false;
                    this.menu.dialog.value = '';
                    break;

                default:
                    break;
            }
        },

        /* ---- Keyboard ---- */

        handleKeyDown(e) {
            if (this.menu.dialog.open) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    this.submitDialog();
                }
                if (e.key === 'Escape') {
                    e.preventDefault();
                    postNui('hideDialog', {});
                }
                // All other keys pass through naturally for text input
                return;
            }

            if (!this.menu.open) return;

            switch (e.key) {
                case 'ArrowUp':
                case 'ArrowDown':
                case 'Enter':
                    e.preventDefault();
                    break;
            }

            switch (e.key) {
                case 'ArrowUp':
                    this.scrollMenu(-1);
                    break;
                case 'ArrowDown':
                    this.scrollMenu(1);
                    break;
                case 'Enter':
                    this.selectCurrentItem();
                    break;
            }
        },

        /* ---- Mouse ---- */

        handleMouseDown(e) {
            if (e.button === 0) {
                // Left click — select current item (only if dialog not open)
                if (!this.menu.dialog.open && this.menu.open) {
                    this.selectCurrentItem();
                }
            } else if (e.button === 2) {
                // Right click — close dialog or close menu
                if (this.menu.dialog.open) {
                    postNui('hideDialog', {});
                } else if (this.menu.open) {
                    postNui('menuItemSelected', { item: { value: 'close' } });
                }
            }
        }
    },

    /* ---- Lifecycle ---- */

    mounted() {
        window.addEventListener('message', this.handleMessage);
        document.addEventListener('keydown', this.handleKeyDown);
        document.addEventListener('mousedown', this.handleMouseDown);

        document.addEventListener('wheel', (e) => {
            if (!this.menu.open || this.menu.dialog.open) return;
            this.scrollMenu(e.deltaY);
        }, { passive: true });

        document.addEventListener('contextmenu', (e) => e.preventDefault());

        // Init Lucide icons on mount
        this.$nextTick(() => { if (window.lucide) lucide.createIcons(); });
    },

    updated() {
        // Re-init Lucide icons after every Vue re-render (new items, icon changes)
        this.$nextTick(() => { if (window.lucide) lucide.createIcons(); });
    },

    beforeDestroy() {
        window.removeEventListener('message', this.handleMessage);
        document.removeEventListener('keydown', this.handleKeyDown);
        document.removeEventListener('mousedown', this.handleMouseDown);
    }
});
