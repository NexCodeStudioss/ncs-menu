menu = {
    open = false,
    dialog = {
        open = false,
        activeCallback = nil,
    },
    currentCallback = nil,
    isStandaloneDialog = false,
    controls = {
        6, 14, 15, 16, 17, 18, 24, 25, 27, 50, 68, 69, 70,
        91, 92, 96, 97, 99, 106, 114, 115, 122, 135, 142,
        144, 176, 177, 180, 181, 198, 222, 223, 229, 237,
        238, 241, 242, 257, 261, 262, 329, 330, 331, 334,
        335, 336, 346, 348, 347
    }
}

-- Ensure string indexing supports .value when checking value == 'close' vs item == 'close'
debug.setmetatable('', {
    __index = function(str, key)
        if key == 'value' then
            return str
        end
        return string[key]
    end
})

-- Control thread to disable weapon and action controls while menu is active
CreateThread(function()
    while true do
        local time = 500

        if menu.open then
            if IsPauseMenuActive() then
                Menu(false)
                time = 500
            elseif not menu.dialog.open then
                time = 0
                BlockWeaponWheelThisFrame()
                for i = 1, #menu.controls do
                    DisableControlAction(0, menu.controls[i], true)
                end
            else
                time = 100
            end
        end

        Wait(time)
    end
end)

-- Exports supporting both colon (Menu:Func) and dot (Menu.Func / exports['ncs-menu']:Func) syntax
exports('CreateNewMenu', function(...)
    CreateNewMenu(...)
end)

exports('CreateNewDialog', function(...)
    CreateNewDialog(...)
end)

exports('CloseDialog', function(...)
    CloseDialog(...)
end)

exports('IsMenuOpen', function(...)
    return IsMenuOpen(...)
end)

exports('CloseMenu', function(...)
    CloseMenu(...)
end)
