--- Normalize arguments to handle both colon syntax (Menu:Method) and dot syntax (Menu.Method)
local function normalizeMenuArgs(...)
    local arg1, arg2, arg3 = ...
    if type(arg1) == 'table' and (type(arg2) == 'string' or type(arg2) == 'table') then
        return arg2, arg3, select(4, ...)
    end
    return arg1, arg2, arg3
end

local function normalizeDialogArgs(...)
    local arg1, arg2, arg3 = ...
    if type(arg1) == 'table' and type(arg2) == 'string' then
        return arg2, arg3, select(4, ...)
    end
    return arg1, arg2, arg3
end

--- Menu Functions

function CreateNewMenu(...)
    local title, items, cb = normalizeMenuArgs(...)

    if menu.open then
        Menu(false)
        Wait(200)
    end

    items = type(items) == 'table' and items or {}
    menu.currentCallback = cb

    Menu(true, {
        title = title or '',
        items = items
    })
end

function Menu(state, data)
    SetNuiFocus(state, false)
    SetNuiFocusKeepInput(state)

    SendNUIMessage({
        type = 'menu:' .. (state and 'show' or 'hide'),
        data = data or {}
    })

    menu.open = state

    if not state then
        menu.currentCallback = nil
        if menu.dialog.open then
            Dialog(false)
        end
    end
end

function CloseMenu()
    Menu(false)
end

function IsMenuOpen()
    return menu.open
end

--- Dialog Functions

function CreateNewDialog(...)
    local title, dialogType, cb = normalizeDialogArgs(...)

    if menu.dialog.open then
        Dialog(false)
        Wait(100)
    end

    menu.dialog.activeCallback = cb

    Dialog(true, {
        title = title or '',
        type = dialogType or 'text'
    })
end

function Dialog(state, data)
    if state and not menu.open then
        -- Standalone dialog opened without an active menu
        menu.open = true
        menu.isStandaloneDialog = true
        SendNUIMessage({
            type = 'menu:show',
            data = { title = '', items = {} }
        })
    end

    if menu.open then
        menu.dialog.open = state

        if state then
            SetNuiFocusKeepInput(false)
            SetNuiFocus(true, true)
        else
            if menu.isStandaloneDialog then
                menu.isStandaloneDialog = false
                menu.dialog.activeCallback = nil
                Menu(false)
                return
            else
                SetNuiFocusKeepInput(true)
                SetNuiFocus(true, false)
            end
        end

        SendNUIMessage({
            type = 'dialog:' .. (state and 'show' or 'hide'),
            data = data or {}
        })

        if not state then
            menu.dialog.activeCallback = nil
        end
    end
end

function CloseDialog()
    Dialog(false)
end

--- Selection and Item Callback Handler

function HandleSelectItem(data)
    if not menu.open then return end
    if not data or not data.item then return end

    local item = data.item

    if item.value == 'close' then
        local cb = menu.currentCallback
        Menu(false)
        if cb then
            cb('close')
        end
        return
    end

    local cb = menu.currentCallback
    if cb then
        cb(item)
    end
end
