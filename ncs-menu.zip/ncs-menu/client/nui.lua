RegisterNUICallback('dialogValueSelected', function(data, cb)
    if cb then cb('ok') end

    local callback = menu.dialog.activeCallback
    local rawValue = data and data.value
    local dialogType = data and data.type

    if callback then
        local formattedValue = rawValue
        if dialogType == 'number' then
            formattedValue = tonumber(rawValue)
        else
            formattedValue = tostring(rawValue or '')
        end

        if formattedValue ~= nil then
            Dialog(false)
            callback(formattedValue)
        end
    else
        Dialog(false)
    end
end)

RegisterNUICallback('menuItemSelected', function(data, cb)
    if cb then cb('ok') end
    HandleSelectItem(data)
end)

RegisterNUICallback('hideDialog', function(data, cb)
    if cb then cb('ok') end
    Dialog(false)
end)
