fx_version 'cerulean'
games { 'gta5' }
author 'NexCodeST and Guerrero Studios'
description 'Menu script for FiveM - NexCode'
lua54 'yes'

client_scripts {
    'client/functions.lua',
    'client/main.lua',
    'client/nui.lua'
}

ui_page 'UI/index.html'

files {
    'UI/index.html',
    'UI/style.css',
    'UI/colors.css',
    'UI/app.js',
    'UI/assets/mouse.gif',
    'UI/assets/fonts/*.ttf',
    'UI/assets/sounds/*.*',
    'UI/**/*.*'
}